/*
 * This program demonstrates the comparison between ship types
 * 
 */

/**
 *
 * @author Simon Shamon
 */

public class SpaceShipDemo {
    
    public static void main (String [] args){
        
        System.out.println("Initializing...");
        
        Spaceship ship = new Spaceship();
        System.out.println(ship.toString());
        
        
        Spaceship shipSimon = new Spaceship(ShipType.ConstructionVessel, "test", 
            "test");
        System.out.println(shipSimon.toString());
        
        
        //testing less than classification
        System.out.println(shipSimon.compareTo(ship) + ": The ship's "
            + "classification is less than otherShip's classification");
        
        
        //testing equal to classification
        Spaceship coffeeShip = new Spaceship();
        if(coffeeShip.equals(ship))
        {System.out.println(coffeeShip.compareTo(ship) + ": The ship's "
            + "classification is equal to otherShip's classification");
        }
 
        
        //testing greater than classification
        Spaceship latteShip = new Spaceship();
        System.out.println(latteShip.compareTo(shipSimon) + ": The ship's "
            + "classification is greater than otherShip's classification");
        
        //comparing ConstructionVessel to ScienceVessel
        System.out.println(ShipType.ConstructionVessel.compareTo(ShipType.ScienceVessel));
        
        
    }
}
